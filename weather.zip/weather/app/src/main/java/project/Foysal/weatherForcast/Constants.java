package project.Foysal.weatherForcast;

public class Constants {
    public static final String  DEFAULT_CITY = "Dhaka";
    public static final String  DEFAULT_LAT = "23.8103";
    public static final String  DEFAULT_LON = "90.4125";
}
